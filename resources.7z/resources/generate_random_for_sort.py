import numpy
import cv2

# generate random single precision float between 0 and 1
nx, ny, nz = 512, 512, 512
arr = numpy.random.rand(nz,ny,nx).astype('float32')
for i in range(nz):
    cv2.imwrite(r"D:\Projects\CudaExample\resources\sort\before\slice_"+str(i)+".tiff", arr[i])

nx, ny, nz = 499, 451, 512
arr = numpy.random.rand(nz,ny,nx).astype('float32')
for i in range(nz):
    cv2.imwrite(r"D:\Projects\CudaExample\resources\sort\tmp\slice_"+str(i)+".tiff", arr[i])

nx, ny = 1024, 8192
arr = numpy.random.rand(ny,nx).astype('float32')
cv2.imwrite(r"D:\Projects\CudaExample\resources\cuda_stream\before.tiff", arr)